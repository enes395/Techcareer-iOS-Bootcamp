

//Muhammed Enes Kılıçlı


import UIKit



//Adres,camelCase

var sehir : String = "Edirne"
var ülke : String = "Burkina Faso"

var telefon : Int = 0555555555
var postaKodu : Int = 34020

var email : String = "kiliclimuhammedenes@gmail.com"
var meslek : String = "Yazılımcı"
var stokMiktarı : Int = 456

var müşteriAdı : String = "Muhammed Enes "

var bakiye : Int = 400
var dogumGünü : String = "1999-07-31"


var maaş : Int = 400
var medeniDurum : String = "Bekar"

var ürünYorum : String = "Gayet Kullanışlı."

var kitapAdı : String = "Hacı Murat"

var ödemeTarihi : String = "2023-05-09"
var ödeme : Int = 350
var siparisAdeti : Int = 350
var arabaModeli  : String = "Hacı Murat"
var yayınlamaTarihi  : String = "2023-05-09"
var ındırımMıktarı  : String
var odaSayısı : String = "2023-05-09"
var enlem : Double = 35.9758
var boylam : Double = -56.6788
var urunAdı : String = "Hacı Murat-Roman-Lev Tolstoy"

//if var yemekFıyatı == 350₺ {
//    print("success")
//}
//else {
//    print("hatali")
//
//
//}

var yemekFıyatı : Int = 350 //350₺ degisken adlarında simge kullanılmaz

var muzikAdı : String = "Lost Soul"
var videoSuresi : Double = 123.45
var urunPuanı : Double = 9.1
var resımAdı : String = "Üç Armut"
//.txt
var dosyaFormatı : String = "Lost Soul"


var marka : String = "Adidas"
var renk : String = "Mavi"
var renkKodu : String = "#66CC33"
var telefonModeli : String = "Redmi 8"
var ekranBoyutu : Double = 6.2
var agırlık : Int = 240
 
var ulusalGun : String = "30 Ağustos Zafer Bayramı"
var tatılGunu : String = "3 Temmuz Pazar"
var rezervasyonTarihi  : String = "2023-11-09"
var sokakAdi  : String = "Uğurevler"
var otobusHattı : String = "Osman Gazi Hattı"

var kalanDakika : Double = 3.20

var takipKodu : UInt = 0000 1234 4321 9876
//let takipKodu : UInt = 0000 1234 4321 9876

var kuponSuresi : Int = "2023-09-06"
var kuponKodu : String = "ilk20"
var faturaAdresi : String = "ilk20"



